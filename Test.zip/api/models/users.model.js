module.exports = (sequelize, Sequelize) => {
    const Users = sequelize.define("users", {
        name: {
            type: Sequelize.STRING,                  //
        },
        phone: {
            type: Sequelize.STRING,                   //
        },
        created: {
            type: Sequelize.DATE,                     //
        },
    }, {
        timestamps: false,
        underscored: true,
    });

    return Users;
};

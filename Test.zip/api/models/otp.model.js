module.exports = (sequelize, Sequelize) => {
    const Otp = sequelize.define("otps", {
        code: {
            type: Sequelize.STRING,
        },
        phone: {
            type: Sequelize.STRING,
        },
        requested: {
            type: Sequelize.DATE,
        },
    }, {
        timestamps: false,
        underscored: true,
    });

    return Otp;
};

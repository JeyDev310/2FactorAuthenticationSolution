const config = require("../config/db.local.config.js");
const Sequelize = require("sequelize");
const sequelize = new Sequelize(
    config.DB,
    config.USER,
    config.PASSWORD,
    {
        host: config.HOST,
        dialect: config.dialect,
        operatorsAliases: '0',

        pool: {
            max: config.pool.max,
            min: config.pool.min,
            acquire: config.pool.acquire,
            idle: config.pool.idle
        },
        logging: false,
    }
);

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

/**
 * Initialize Table
 */
db.users = require("./users.model")(sequelize, Sequelize);
db.otp = require("./otp.model")(sequelize, Sequelize);

db.sequelize.sync();
module.exports = db;
module.exports = {
    SIM_API_URL: "http://192.168.1.6:8000/",
    EXPIRESIN: 60 * 1000,   // 60s
    EXP: 31556926,
    /**
     * Secret key for JWT
     */
    SECRET_KEY: "MIICWQIBAAKBgEy3YzkLsosLAJoxWyYNUUWH5wAyq2DSK8IAPJm7r34CqlYNyNSk",
};

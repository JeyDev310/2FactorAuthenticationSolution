const Validator = require("validator");
const isEmpty = require("is-empty");

module.exports = function createCode( data ) {
	data.phone = !isEmpty( data.phone.toString() ) ? data.phone.toString() : "";
	if ( Validator.isEmpty( data.phone )) {
		return {
			status: false,
			msg: "Invalid input",
		};
	}
	let chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
	let code_temp = '';
	for( let i = 0; i< 6; i ++ ) {
		code_temp += chars.charAt( Math.floor(Math.random()*chars.length ));
	}
	console.log(code_temp);
	return {
		status: true,
		results: code_temp,
	};
};
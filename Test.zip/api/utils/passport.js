const JwtStrategy = require("passport-jwt").Strategy;
const ExtractJwt = require("passport-jwt").ExtractJwt;
const db = require("../models");
const Users = db.users;
const {SECRET_KEY} = require("../config/config");

const opts = {};
opts.jwtFromRequest = ExtractJwt.fromAuthHeaderAsBearerToken();
opts.secretOrKey = SECRET_KEY;

module.exports = async passport => {
    await passport.use(
        await new JwtStrategy(opts, (jwt_payload, done) => {
            Users.findOne(
                {
                    where: { id: jwt_payload.id, },
                }
            ).then(async user => {
                if (user) {
                    return done(null, true);
                } else {
                    return done(null, false);
                }
            }).catch(err => console.log(err));
        })
    );
};

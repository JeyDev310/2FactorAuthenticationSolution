const jwt = require("jsonwebtoken");
const config = require("../config/config");
/**
 * generating the Token by Security_key
 */
module.exports = function generate_security_token( data ) {
    try {
        const payload = {
            phone: data.phone,
        };
        let expireTime = { expiresIn: config.EXP };
        let temp = jwt.sign(payload, config.SECRET_KEY, expireTime);
        if (temp) {
            return {
                status: true,
                result: "Bearer " + temp,
            };
        } else {
            return {
                status: false,
            };
        }
    } catch (e) {
        return {
            status: false,
            msg: e.toString(),
        };
    }
};
const express = require("express");
const router = express.Router();

const db = require("../models");
const Otp = db.otp;
const generate_security_token = require("../utils/generateToken");
const createCode = require("../utils/generateCode");
const config = require("../config/config");

router.all("/get-code", async ( req, res ) => {
    try {
        let code = await createCode(req.body);
        if ( !code.status ) {
            return res.status(200).json({ status: false, msg: code.msg });
        }
        await Otp.create({
            code: code.results.toLowerCase(),
            phone: req.body.phone,
            requested: new Date(),
        });
        return res.status(200).json({ status: true, msg: " We sent the code to the phone. Please check your phone.", code: code.results });
    } catch (e) {
        return res.status(200).json({ status: false, msg: e.toString() });
    }
});
router.all("/confirm-code", async ( req, res ) => {
    try {
        let code = await Otp.findOne({
            where: {
                code: req.body.code.toLowerCase(),
            }
        });
        if ( code ) {
            let time_expire = new Date().getTime() - new Date( code.requested ).getTime();
            console.log(time_expire, config.EXPIRESIN)

            if ( time_expire > config.EXPIRESIN ) {
                console.log(time_expire)
                return res.status(200).json({ status: false, msg: "Please regenerate the code"});
            } else {
                let token = await generate_security_token({ phone: code.phone });
                if ( token && token.status )
                    return res.status(200).json({ status: true, msg: "Login Succeed", results: { token: token.result, phone: code.phone }});
            }
        }
        return res.status(200).json({ status: false, msg: "Mistaken request"});
    } catch (e) {
        return res.status(200).json({ status: false, msg: e.toString() });
    }
});

module.exports = router;
const express = require("express");
const router = express.Router();
const {Op, Sequelize} = require("sequelize");
const passwordHash = require('password-hash');

const db = require("../models");
const Users = db.users;

router.all("/register-admin", async (req, res) => {
    try {
        if (req.body.jwt_data.role !== 'super') {
            return res.status(200).json({status: false});
        }
        // const {msg, isValid} = await validateRegisterAdmin(req.body);

        // if (!isValid) {
        //     return res.status(200).json({status: false, msg: msg});
        // }
        let temp_id = await Users.findOne({
            where: {
                admin_id: req.body.admin_id,
                deleted_date: null,
            },
            attributes: ['admin_id'],
        });

        let temp_name = await Users.findOne({
            where: {
                name: req.body.name,
                deleted_date: null,
            },
            attributes: ['name'],
        });
        if (temp_id) {
            return res.status(200).json({status: false});
        } else if (temp_name){
            return res.status(200).json({status: false});
        } else {
            const new_admin = {
                role: 'admin',
                name: req.body.name,
                admin_id: req.body.admin_id,
                admin_password: passwordHash.generate(req.body.password),
                registered_date: new Date().toUTCString(),
            };

            await Users.create(new_admin);
            return res.status(200).json({status: true});
        }
    } catch (e) {
        return res.status(200).json({status: false, msg: [e.toString()]});
    }
});


router.all("/login-user", async (req, res) => {
    try {
        console.log(req.body, ' = User Login');
        /**
         * JWT verification
         */
        let temp = await verify_token(req.body);
        if (temp.state === false || temp.result.payload.phone !== req.body.phone) {
            return res.status(200).json({status: false});
        }

        if (!isValid) {
            return res.status(200).json({status: false, msg: msg});
        }
        let user = await Users.findOne({
            where: {
                phone: req.body.phone,
            }
        });

        if (user) {
            if (user.deleted_date) {
                return res.status(200).json({status: false});
            }
            if (user.suspended_date) {
                return res.status(200).json({status: false});
            }
            let token = await generate_security_token(user);
            console.log(token, ' = token');
            if (token.status === false) {
                return res.status(200).json({status: false, msg: [token.flag]});
            } else {
                let user_data = {
                    id: user.id,
                    last_login_date: new Date().toUTCString(),
                    latitude: req.body.latitude,
                    longitude: req.body.longitude,
                    online_status: true,
                    first_login_status: true,
                };
                await Users.update(
                    user_data,
                    {where: {id: user.id}},
                );

                let temp_user = await Users.findOne({
                    where: {
                        id: user.id,
                    },
                    include: [{
                        model: PassToUse,
                    }]
                });
                const temp = Object.assign({}, temp_user['dataValues'], {token: token.result});
                return res.status(200).json({status: true, results: temp});
            }
        } else {
            return res.status(200).json({status: false});
        }
    } catch (e) {
        return res.status(200).json({status: false, msg: [e.toString()]});
    }
});

module.exports = router;
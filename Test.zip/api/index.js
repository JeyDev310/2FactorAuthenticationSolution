const express = require("express");
const cors = require('cors');
const app = express();
const bodyParser = require("body-parser");
const path = require('path');

const passport = require("passport");
const auth = require("./routes/auth");
const users = require("./routes/user");

app.use(
    cors({
        origin: '*',
        methods: ["GET", "POST"],
    })
);

app.use( // Body-parser middleware
    bodyParser.json({
        limit: '50mb',
    }));

app.use(passport.initialize(null)); // Passport middleware
require("./utils/passport")(passport);      // Passport config

app.use(express.static('public'));
app.use("/public", express.static("public"));

const publicPath = path.join(__dirname, 'build');
app.use(express.static(publicPath));

async function check(req, res, next) {
    passport.authenticate('jwt', {session: false}, function (err, data) {
        if (err) {
            return res.status(403).send({err: err.toString()});
        } else {
            if (data === false) {
                return res.status(403).send({msg: "Mistaken token"})
            } else {
                req.body['jwt_data'] = data;
                return next();
            }
        }
    })(req, res, next);
}
app.use("/api/auth", auth);
app.use("/api/users", check, users);

const server = require('http').createServer(app);
const port = process.env.PORT || 8000;
server.listen(port, () => console.log(`Server up and running on port ${port}!`));
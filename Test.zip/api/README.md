# Back-end: node Express.js

## Quick start
```
    npm install
    npm start
```

The launched server will be listening on the port 8000.

Please consider the following section before launching the server.

### `FONT_URL`
ex)
```
http://127.0.0.1:8000/
```
## For the production
For the production, please consider a file: `config.js`.

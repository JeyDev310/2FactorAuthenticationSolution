# Testing
React Typescript Test : a simple demonstration for OTP authentication.
A simple front-end and back-end of a simple two-factor authentication solution.
The front-end is based on the React.js framework with Typescript.
 - a simple user interface to accept the phone number that the user wants to validate
 - when the user entered a one-time password that he/she saw from his/her phone, shows the validation result (that is, if the password is correct or not) after some time. 
 - if the code that the user entered is not correct, the user can request a new OTP.
The back-end API is based on Node.js (express) with Typescript.
 - create six-digit authentication code (one-time password, OTP) that expires after a predefined amount of time, say 60 seconds
 - send the above authentication code via SMS to a phone number that the user entered.
 - validate the authentication code with the one entered by the user.
 
# npm install

# npm start


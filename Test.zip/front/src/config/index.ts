export default {
	SIM_API_URL: "http://192.168.1.6:8000/",
	FRONT_URL: 'http://localhost:3000',
};

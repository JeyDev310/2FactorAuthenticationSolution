import React from "react";
import { Route, Redirect } from "react-router-dom";
import { connect } from "react-redux";

// @ts-ignore
const PrivateRoute = ({ component: Component, ...rest }) => {
    const loggedIn = localStorage.getItem('auth');
    return (
        <Route
            { ...rest }
            render={ props =>
                loggedIn !== '' && loggedIn !== null && loggedIn !== undefined? (
                    <Component {...props} />
                ) : (
                    <Redirect to="/login" />
                )
            }
        />
    )
};

PrivateRoute.propTypes = {
    // auth: PropTypes.object.isRequired
};

const mapStateToProps = () => ({
    // auth: state.auth
});

export default connect( mapStateToProps )( PrivateRoute );

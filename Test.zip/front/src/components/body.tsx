import React from 'react';
import { Redirect, Switch } from "react-router-dom";
import PrivateRoute from "./privateRoute";
import Home from "./home";

export default function Body () {
	return (
		<>
			<Switch>
				<PrivateRoute
					path='/home'
					component={ Home }
				/>
				<Redirect
					to='/home'
				/>
			</Switch>
		</>
	)
}


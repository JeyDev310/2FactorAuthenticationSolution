import React, { useEffect } from 'react';
import { useHistory, useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {
    reset,
    getCode,
    sendConfirm,
} from "../redux/actions/register/user";

interface IProps {
}
const Login: React.FC<IProps> = () => {
    const dispatch = useDispatch();
    const store: any = useSelector( state => state );
    const history = useHistory();
    const location = useLocation();
    const [ phone, setPhone ] = React.useState<any>( "" );
    const [ code, setCode ] = React.useState<any>( "" );
    const [ isFlag, setIsFlag ] = React.useState<boolean>( false );

    useEffect( () => {
        if ( location.pathname === "/login" ) {
            localStorage.setItem( "auth", "" );
            localStorage.setItem( "phone", "" );
        }
    }, [ location.pathname ] );
    /** Generating the code **/
    useEffect( () => {
        if ( store?.registers?.get_code ) {
            toast( store?.registers?.get_code.msg );
            if ( store?.registers?.get_code.status ) {
                setIsFlag( true );
                toast( "Code: " + store?.registers?.get_code.code );
            }
            setTimeout( () => {
                dispatch( reset() );
            }, 1000 )
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [ store?.registers?.get_code ] );
    const sendRequest = ( e: any ) => {
        e.preventDefault();
        dispatch( getCode({ phone: phone }) );
    };

    /** Confirmation **/
    useEffect( () => {
        if ( store?.registers?.get_login ) {
            toast( store?.registers?.get_login.msg );
            if ( store?.registers?.get_login.status ) {
                localStorage.setItem( "auth", store?.registers?.get_login.results.token );
                localStorage.setItem( "phone", store?.registers?.get_login.results.phone );
                setTimeout( () => {
                    dispatch( reset() );
                    history.push("/home" );
                }, 1500 )
            } else {
                setTimeout( () => {
                    dispatch( reset() );
                }, 1500 )
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [ store?.registers?.get_login ] );
    const onVerify = ( e: any ) => {
        e.preventDefault();
        dispatch( sendConfirm( { code: code } ));
    };
    return (
        <div>
            <div className={"spinning-curtain"} style={{ display: store.spinning ? "flex" : "none" }}>
                <div className="lds-dual-ring"/>
            </div>
            <div>
                <ToastContainer/>
            </div>
            <div className="login-bg">
                <div className="register-body animate-zoom">
                    <div className="txt-bold txt-42 justify-center pt-20 pb-50">LOGIN</div>
                    <form onSubmit={ sendRequest }>
                        <div className="flex-space">
                            <input
                                id="phone"
                                type="tel"
                                value={ phone }
                                placeholder="Please input your phone number"
                                onChange={ ( e ) => setPhone( e.target.value ) }
                            />
                            <button type="submit" className="btn-common txt-16 col-white justify-center mouse-cursor">
                                Receive Code
                            </button>
                        </div>
                    </form>
                    {
                        isFlag && (
                            <form onSubmit={ onVerify }>
                                <div className="flex-space">
                                    <input
                                        id="code"
                                        type="text"
                                        value={ code }
                                        placeholder="Please input the verification code"
                                        onChange={ ( e ) => setCode( e.target.value ) }
                                    />
                                    <button type="submit" className="btn-common txt-16 col-white justify-center mouse-cursor">
                                        Verify
                                    </button>
                                </div>
                            </form>
                        )
                    }
                </div>
            </div>
        </div>
    )
};

export default Login;
import React from 'react';
interface IProps {
}

const Home: React.FC<IProps> = () => {
    return (
        <div className="justify-center pt-20 txt-42">
            Welcome !
        </div>
    )
};
export default Home;
import React from 'react';
import '../src/assets/css/index.css';
import { Switch, Redirect, BrowserRouter as Router, Route } from "react-router-dom";

import Body from "./components/body";
import Login from "./components/login";
import PrivateRoute from "./components/privateRoute";

export default function App () {
    return (
        <Router>
            <Switch>
                <PrivateRoute
                    path='/home'
                    component={ Body }
                />
                <Route
                    path='/login'
                    component={ Login }
                />
                <Redirect
                    to='/home'
                />
            </Switch>
        </Router>
    )
}
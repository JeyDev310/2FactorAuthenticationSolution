import {
	GET_DATA,
	SHOW_SPINNING,
	GET_LOGIN,
} from "../actions/types/types"

const initialState = {
	spinning: '',
	get_code: '',
	get_login: '',
};

export default function( state = initialState, action: { type: any; payload: any; }) {
	switch( action.type ) {
		case SHOW_SPINNING:
			return {
				...state,
				spinning: action.payload,
			};
		case GET_DATA:
			return {
				...state,
				get_code: action.payload,
			};
		case GET_LOGIN:
			return {
				...state,
				get_login: action.payload,
			};
		default:
			return state;
	}
}

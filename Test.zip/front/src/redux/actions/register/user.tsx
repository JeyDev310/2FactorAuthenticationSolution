import axios from "axios";
import config from "../../../config";
import {
    SHOW_SPINNING,
    GET_DATA,
    ERR_MESSAGE,
    GET_LOGIN,
} from "../types/types";

const instance = axios.create({
    baseURL: config.SIM_API_URL,
    timeout: 30000,
    headers: { 'Authorization': "" }
});

// Add a response interceptor
instance.interceptors.response.use(function ( response) {
    return response;
}, function ( error ) {
    if ( error.response.status === 403 ) {
        console.log( error, ' = token error' );
        window.location.href = "/";
    }
    return Promise.reject( error );
});

export const reset = () => async ( dispatch: any ) => {
    dispatch({
        type: ERR_MESSAGE,
        payload: '',
    });
    dispatch({
        type: SHOW_SPINNING,
        payload: '',
    });
    dispatch({
        type: GET_DATA,
        payload: '',
    });
    dispatch({
        type: GET_LOGIN,
        payload: '',
    })
};

export const getCode = ( data: any ) => async ( dispatch: any ) => {
    dispatch({ type: SHOW_SPINNING, payload: true });
    axios
        .post( config.SIM_API_URL + "api/auth/get-code", data )
        .then( res => {
            dispatch({ type: SHOW_SPINNING, payload: false });
            dispatch({
                type: GET_DATA,
                payload: res.data,
            });
        })
        .catch( err => {
            dispatch({ type: SHOW_SPINNING, payload: false } );
        })
};
export const sendConfirm = ( data: any ) => async ( dispatch: any ) => {
    dispatch({ type: SHOW_SPINNING, payload: true });
    axios
        .post( config.SIM_API_URL + "api/auth/confirm-code", data )
        .then( res => {
            dispatch({ type: SHOW_SPINNING, payload: false });
            dispatch({
                type: GET_LOGIN,
                payload: res.data,
            });
        })
        .catch( err => {
            dispatch({ type: SHOW_SPINNING, payload: false } );
        })
};

export const SHOW_SPINNING = "SHOW_SPINNING";
export const GET_DATA = "GET_DATA";
export const ERR_MESSAGE = "ERR_MESSAGE";
export const GET_LOGIN = "GET_LOGIN";
